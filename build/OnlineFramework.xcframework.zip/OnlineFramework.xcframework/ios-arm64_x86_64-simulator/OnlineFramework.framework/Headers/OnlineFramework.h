//
//  OnlineFramework.h
//  OnlineFramework
//
//  Created by Rilwanul Huda on 04/04/23.
//

#import <Foundation/Foundation.h>

//! Project version number for OnlineFramework.
FOUNDATION_EXPORT double OnlineFrameworkVersionNumber;

//! Project version string for OnlineFramework.
FOUNDATION_EXPORT const unsigned char OnlineFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OnlineFramework/PublicHeader.h>


